ffrom flask import Flask, request, jsonify
import mysql.connector

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="tuapassword",
    database="piattaforma_studenti"
)
cursor = db.cursor(dictionary=True)

@app.route('/studenti', methods=['GET'])
def get_studenti():
    cursor.execute("SELECT * FROM studenti")
    return jsonify(cursor.fetchall())

@app.route('/registrati', methods=['POST'])
def registra_studente
::contentReference[oaicite:1]{index=1}
 
