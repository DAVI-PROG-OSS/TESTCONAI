document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registrationForm');
  const list = document.getElementById('studentList');
  const studenti = JSON.parse(localStorage.getItem('studenti')) || [];

  // Mostra studenti se siamo in index.html
  if (list) {
    studenti.forEach(s => {
      const li = document.createElement('li');
      li.textContent = `${s.nome} ${s.cognome} - ${s.email} - ${s.corso}`;
      list.appendChild(li);
    });
  }

  // Aggiungi nuovo studente se siamo in registrati.html
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const studente = {
        nome: form.nome.value.trim(),
        cognome: form.cognome.value.trim(),
        nascita: form.nascita.value,
        email: form.email.value.trim(),
        corso: form.corso.value.trim()
      };

      if (!studente.nome || !studente.cognome || !studente.nascita || !studente.email || !studente.corso) {
        alert("Compila tutti i campi correttamente.");
        return;
      }

      studenti.push(studente);
      localStorage.setItem('studenti', JSON.stringify(studenti));
      alert("Registrazione completata!");
      form.reset();
    });
  }
});

  